import { GITHUB } from '@/config'
import Layout from '@/layout/welcome'
import lazy from '@/components/Lazy'

export default {
  path: '/',
  name: 'home',
  component: Layout,

}

